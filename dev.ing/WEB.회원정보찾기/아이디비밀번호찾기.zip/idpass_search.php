<div>
    <!--탭-->
</div>

<!--아이디찾기-->
<div class="">
    <!--아이디찾기 완료페이지 링크 action에 넣어주세요 -->
    <form method="POST" action="/">
        <input name="username" type="text" placeholder="가입하실때 입력하신 이름을 입력해주세요.">
        <input name="userphone" type="text" placeholder="가입하실때 입력하신 전화번호를 입력해주세요.">
        <input type="submit" value="아이디 찾기">
    </form>
</div>

<!-- 비밀번호찾기-->
<div class="">
    <!--비밀번호찾기 완료페이지 링크 action에 넣어주세요 -->
    <form method="POST" action="/">
        <input name="userid" type="text" placeholder="아이디를 입력해주세요.">
        <input name="userphone" type="text" placeholder="가입하실때 입력하신 전화번호를 입력해주세요.">
        <input type="submit" value="비밀번호 찾기">
    </form>
</div>